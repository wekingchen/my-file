/* SPDX-License-Identifier: GPL-2.0 */
/* Copyright (c) 2021 MediaTek Inc. */

#ifndef _DT_BINDINGS_RESET_MT7986
#define _DT_BINDINGS_RESET_MT7986

#define MT7986_TOPRGU_CONSYS_RST	23
#define MT7986_TOPRGU_SW_RST_NUM	32

#endif  /* _DT_BINDINGS_RESET_MT7986 */
