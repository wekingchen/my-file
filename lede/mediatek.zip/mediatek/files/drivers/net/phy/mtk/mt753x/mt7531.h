/* SPDX-License-Identifier: GPL-2.0-only */
/*
 * Copyright (c) 2018 MediaTek Inc.
 */

#ifndef _MT7531_H_
#define _MT7531_H_

#include "mt753x.h"

extern struct mt753x_sw_id mt7531_id;

#endif /* _MT7531_H_ */
